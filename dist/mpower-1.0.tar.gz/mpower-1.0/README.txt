# mPower
Control mPower Pro Units


Python Code to connect to mPower unit and either turn on, or off, a a port


#Usage

Run 'python setup.py install' to import the modules

OR

run "python mpower.py x y z'

Where z would be the host ip, 2 is the port # to change, and z is 'up' or 'down'.  

#Example

>python mpower.py 127.0.0.1 2 up

Change the status of 2 on host 127.0.0.1 to up

