# mPower
Control mPower Pro Units


Python Code to connect to mPower unit and either turn on, or off, a a port
